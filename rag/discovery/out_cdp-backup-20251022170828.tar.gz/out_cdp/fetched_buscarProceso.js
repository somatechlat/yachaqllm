var estadoSeleccionado = '';
var totProcesos;
var registroxPagina = 20;
var newwindow;
var fechaOcultaSIE;
var usbo;
var muestraTipoCompra;
var fechaBanderaLink = '';
//Mantis 2251 - Actualizacion de funcion para validacion de Campos
//Mantis 2994 - Pasajes aéreos - Tipos de Procedimientos para los cuales aplica filtro y visualización Tipo de compra
function botonBuscar() {
    $('paginaActual').value = 0;
    var cmbEstado = document.getElementsByName("cmbEstado").length;
    if (cmbEstado > 0) {
        if ($('cmbEstado').value === '416' && fechaBanderaLink === '') {
            //Mantis 3512 - 7950 - Habilitar link borrado de borradores procedimientos creados desde 2021                     
            var data = "cod=" + 'FECHA_BORR_2021';
            var clazz = "Parametro";
            var action = "buscarValorParametroSIE";
            ajax_call(data, clazz, action, val);

            function val(result, resp) {
                fechaBanderaLink = formatoFecha(result['valor'] + ' 00:00:00');
            }
        }
    }
    if (validarFechas()) {
        numeroProcesos(0);
    }
}

function numeroProcesos(result) {
    asignarImagenCargando('cargando');

    if (result === 'false' || result === false) {
        //alert('Registro de procedimiento eliminado exitosamente');
        alert('La eliminación del registro se realizó exitosamente. Usted podrá reutilizar el código del procedimiento eliminado.');
    } else if (result === 'true' || result === true) {
        alert('Usted no podrá eliminar este procedimiento de contratación, puesto que existe una AUTOC vinculada a este procedimiento');
    } else if (result !== '' && result.length > 1) {
        alert(result);
    }

    var data = Form.serialize($('frmDatos'));
    var clazz = "SolicitudCompra";
    var action = "buscarProcesoxEntidadCount";

    ajax_call(data, clazz, action, contarProcesos);
}


function contarProcesos(result, resp) {

    if (result !== "") {
        totProcesos = result['count'];
        $('count').value = result['count'];
    }
    presentarProcesosInicial(0);
}

//ET Mantis 3066
function presentarProcesosInicial(offset) {
    $('paginaActual').value = offset;
    document.getElementById("captccc2").value = 1;
    var data = Form.serialize($('frmDatos'));
    var clazz = "SolicitudCompra";
    var action = "buscarProcesoxEntidad";

    ajax_call(data, clazz, action, listarProcesos);
}

function presentarProcesos(offset) {
    $('paginaActual').value = offset;
    document.getElementById("captccc2").value = 2;//ET Mantis 3066
    var data = Form.serialize($('frmDatos'));
    var clazz = "SolicitudCompra";
    var action = "buscarProcesoxEntidad";

    ajax_call(data, clazz, action, listarProcesos);
}

function buscarProcesoGestContFFF(result) {
    if (result === '1') {
        alert(result);
    }
}
function generarCaptcha(offset) {
    $('paginaActual').value = offset;
    var data = Form.serialize($('frmDatos'));
    var clazz = "SolicitudCompra";
    var action = "buscarProcesoxEntidad";

    ajax_call(data, clazz, action, listarProcesos);
}

//listar
function listarProcesos(result, resp) {
    $('cargando').innerHTML = '';
    if (result === "fallo") {
        $('divProcesos').innerHTML = '<B> <font SIZE=2 color="red">Captcha Incorrecto</font></B> ';
    } else if (result === "") {
        $('divProcesos').innerHTML = '<B> <font SIZE=2 color="red">No existen procesos para la consulta ingresada</font></B>';
    } else {
        consultaParametro();
        res = abrirTabla();
        res += nuevaCabecera();
        result.each(function (regProcesos) {
            //console.log(regProcesos);
            res += nuevaFila();
            res += nuevaCeldaLink(regProcesos.c, regProcesos.i, regProcesos.v);
            res += nuevaCelda(regProcesos.r);
            res += nuevaCelda(regProcesos.d);
            res += nuevaCelda(regProcesos.g);
            if (muestraTipoCompra === 'SI') {
                if (regProcesos.j) {
                    res += nuevaCelda(regProcesos.j); //Tipo de compra
                } else {
                    res += nuevaCelda('');
                }
            }
            res += nuevaCelda(regProcesos.s);
            if (regProcesos.t === 4505)
                res += nuevaCelda('No aplica');
            else if (regProcesos.t === 4504) {
                res += nuevaCelda(formatoMoneda4Dec(regProcesos.p));
            } else {//Mantis 2741: Controles para la visualizacion del precio referencial - Isabel Montero 24/01/2017
                if (regProcesos.t === 386) {
                    var estados = ["Adjudicada", "Finalizada", "Adjudicado - Registro de Contratos", "Ejecución de Contrato", "En Recepción"];
                    if (regProcesos.g === 'Borrador' && regProcesos.z !== '') {
                        var fechaPub = regProcesos.z;
                    } else {
                        var fechaPub = regProcesos.f;
                    }
// se comenta este codigo para presup referencial visible en SIE                    
//                    if (!inArray(regProcesos.g, estados) && regProcesos.u !== '' && fechaPub > fechaOcultaSIE) {
//                        res += nuevaCelda('NO DISPONIBLE');
//                    } else {
                        res += nuevaCelda(formatoMoneda(regProcesos.p));
//                    }
                } else {//Fin cambios 2741
                    res += nuevaCelda(formatoMoneda(regProcesos.p));
                }
            }
            res += nuevaCelda(regProcesos.f);
            if (regProcesos.g === 'Borrador') {
                fechaProceso = formatoFecha(regProcesos.f + ' 00:00:00');

                if (fechaProceso >= fechaBanderaLink) {
                    res += nuevaCeldaOpcionEliminar(regProcesos.g, regProcesos.i, fechaProceso);
                }
            } else {
                res += nuevaCeldaOpcion(regProcesos.e, regProcesos.i);
            }
            res += cerrarFila();
        });
        res += cerrarTabla();
        res += dibujarPaginadores();
        $('divProcesos').innerHTML = res;
    }

    $("linkReload").click();
}

//PARA DIBUJAR LAS TABLAS Y DIVS
function abrirTabla() {
    return '<table width="100%" border="0">\n';
}

//Cerrar tablas
function cerrarTabla() {
    return '</table>';
}

function nuevaCeldaOpcion(opcion, id) {
    if (opcion === 'modFecha') {
        return '<td valign="top" align="left"><a href="modificacionFecha.cpe?idSoliCompra=' + id + '">Cambio de Cronograma</a></td>'; /// alias
    } else {
        return '<td>&nbsp;</td>';
    }
}

function nuevaCeldaLink(registro, id, version) {
    version = parseInt(version);
    if (version === -1 || version === -2) {
        return '<td valign="top" align="left"><a href="../SC/sci.cpe?idSoliCompra=' + id + '">' + registro + '</a></td>'; /// alias
    } else if (version === 2) {
        return '<td valign="top" align="left"><a class="__modal__" href="informacionProcesoContratacion2.cpe?idSoliCompra=' + id + '">' + registro + ' </a></td>';  /// alias
    } else if (version === 3) {  // para ferias inclusivas
        return '<td valign="top" align="left"><a href="../CR/mostrarferiainicial.cpe?idSoliCompra=' + id + '">' + registro + '</a></td>';
    } else {
        return '<td valign="top" align="left"><a href="informacionProcesoContratacion.cpe?idSoliCompra=' + id + '">' + registro + '</a></td>'; /// alias
    }
}

function nuevaCeldaOpcionEliminar(opcion, id, fechaProceso = '') {
    //Mantis 3512 - 7950 - Habilitar link borrado de borradores procedimientos creados desde 2021                     
    var data = "cod=" + 'FECHA_BORR_2021';
    var clazz = "Parametro";
    var action = "buscarValorParametroSIE";
    ajax_call(data, clazz, action, val);

    function val(result, resp) {
        fechaBanderaLink = formatoFecha(result['valor'] + ' 00:00:00');
    }

    habilitaLinkBorrador(id);
    if (usbo === 'true') {
        if (opcion === 'Borrador') {
            if (fechaProceso >= fechaBanderaLink) {
                return '<td valign="top" align="left"><a onclick="eliminar(\'' + id + '\')" href="javascript:void(0);" >Eliminar</a></td>'; /// alias
            } else {
                return '<td>&nbsp;</td>';
            }
        } else {
            return '<td>&nbsp;</td>';
        }
    } else {
        return '<td>&nbsp;</td>';
}
}

function eliminar(id) {
    var idus = document.getElementById("idus").value;
    var UsuarioID = document.getElementById("UsuarioID").value;
    var data = "idSoliCompra= " + id + "&idus=" + idus + "&UsuarioID=" + UsuarioID;
    var clazz = "SolicitudCompra";
    var action = "EliminarProcesoEstadoBorrador";

    if (confirm('¿Esta seguro que desea eliminar el registro de este procedimiento?')) {
        asignarImagenCargando('cargando');
        ajax_call(data, clazz, action, numeroProcesos);
    }
}

function habilitaLinkBorrador(id) {
    var idus = document.getElementById("idus").value;
    var data = "idSoliCompra= " + id + "&idus=" + idus;
    var clazz = "SolicitudCompra";
    var action = "validaUsuarioBorrador";
    ajax_call(data, clazz, action, respuestaActivaLinkBorrador);
}

function respuestaActivaLinkBorrador(result) {
    usbo = result;
    return result;
}

function enSupervision() {
    //(En Supervisión*)
}

//Nueva celda
function nuevaCelda(registro) {
    return '<td valign="top" align="left">\n' + registro + '</td>';
}

//Nueva fila
function nuevaFila() {
    return '<tr>\n';
}

//Cerrar fila
function cerrarFila() {
    return '</tr>\n';
}

//Crear cabecera
function nuevaCabecera() {
    res = '<tr class="filaTitulo">';
    if (isset($('cmbEstado'))) {
        if (esProveedor === 'C' && parseInt($F('cmbEstado')) === 416) {
            if (muestraTipoCompra === 'SI') {
                cabecera = new Array('C&oacute;digo', 'Entidad Contratante', 'Objeto del Proceso', 'Estado del Proceso', 'Tipo de Compra',
                        'Provincia/Cant&oacute;n', 'Presupuesto Referencial Total(sin iva)', 'Fecha de Creaci&oacute;n', 'Opciones');
            } else {
                cabecera = new Array('C&oacute;digo', 'Entidad Contratante', 'Objeto del Proceso', 'Estado del Proceso',
                        'Provincia/Cant&oacute;n', 'Presupuesto Referencial Total(sin iva)', 'Fecha de Creaci&oacute;n', 'Opciones');
            }
        } else {
            if (muestraTipoCompra === 'SI') {
                cabecera = new Array('C&oacute;digo', 'Entidad Contratante', 'Objeto del Proceso', 'Estado del Proceso', 'Tipo de Compra',
                        'Provincia/Cant&oacute;n', 'Presupuesto Referencial Total(sin iva)', 'Fecha de Publicaci&oacute;n', 'Opciones');//                        
            } else {
                cabecera = new Array('C&oacute;digo', 'Entidad Contratante', 'Objeto del Proceso', 'Estado del Proceso',
                        'Provincia/Cant&oacute;n', 'Presupuesto Referencial Total(sin iva)', 'Fecha de Publicaci&oacute;n', 'Opciones');//
            }
        }
    } else {
        if (muestraTipoCompra === 'SI') {
            cabecera = new Array('C&oacute;digo', 'Entidad Contratante', 'Objeto del Proceso', 'Estado del Proceso', 'Tipo de Compra',
                    'Provincia/Cant&oacute;n', 'Presupuesto Referencial Total(sin iva)', 'Fecha de Publicaci&oacute;n', 'Opciones');//		                
        } else {
            cabecera = new Array('C&oacute;digo', 'Entidad Contratante', 'Objeto del Proceso', 'Estado del Proceso',
                    'Provincia/Cant&oacute;n', 'Presupuesto Referencial Total(sin iva)', 'Fecha de Publicaci&oacute;n', 'Opciones');//		
        }
    }
    cabecera.each(function (cab) {
        res += '<td align="left" id="fondoth">' + cab + '</td>\n';
    });
    res += "</tr>";
    return res;
}

function cargarEstados() {
    var html = '';
    var arregloEstadosActual;
    var tipoCompra;
    tipoCompra = $("txtCodigoTipoCompra").value;
    if (tipoCompra !== '') {
        var arregloTodos = Array('', '', '', '', 'TODOS');
        arregloEstadosActual = generarArregloBuscarConArreglo(arregloEstados, tipoCompra, 1, arregloTodos);
        html = Combo(arregloEstadosActual, estadoSeleccionado, 'cmbEstado', true, '', 40, '', 3, 4, '', '', '');
        $("divEstadosProcesos").innerHTML = html;
    } else {
        $("divEstadosProcesos").innerHTML = '';
    } //Fin tipoCompra != ''
}

function buscarGoogle() {
    location.href = "http://www.google.com.ec/advanced_search?hl=es&as_sitesearch=www.compraspublicas.gob.ec&as_q=" + $F('txtPalabrasClaves');
}

//Mantis 2251 - Actualizacion de funcion
//Mantis 2461 - Actualizacion ET 
function dibujarComboEstados(idProceso) {
    if (idProceso !== "") {
        if (idProceso === 7116) { //Mantis 3053: Mostrar combo de tipo de Arrendamiento para los procesos 7116
            $('tipoArrendamiento').style = 'display:table-row';
            consultaEstadosPE(249);
        } else if (idProceso === 7115) {
            $('tipoArrendamiento').style = 'display:none';
        }
        html = '<select id="cmbEstado" onblur="this.style.background="#FFFFFF"; " onfocus="this.style.background="#FFFF99"; " name="cmbEstado">';
        html += '<option value="" selected="selected">TODOS</option>';
        //Mantis 2251
        arregloEstados.each(function (val) {
            if (val[0] === idProceso) {
                if (val[1] === 54028) {
                    if ($('cmbTipoCompra') !== null) {
                        if ($('cmbTipoCompra').value === '' || $('cmbTipoCompra').value === 7)
                            html += '<option value="' + val[1] + '">' + val[2] + '</option>';
                    } else {
                        html += '<option value="' + val[1] + '">' + val[2] + '</option>';
                    }
                } else {
                    html += '<option value="' + val[1] + '">' + val[2] + '</option>';
                }
            }
        });
        html += '</select>';
    } else {
        $('tipoArrendamiento').style = 'display:none';
        html = '';
    }

    document.getElementById('divEstadosProcesos').innerHTML = html;
}

//Filtra Tipo de Compra de acuerdo al Tipo de Contratación Mantis 2994
function consultaTipoCompra(TipoContratacion) {
    if (TipoContratacion !== '') {
        var data = "idTipo=" + TipoContratacion;
        var clazz = "TcomTipoProceso";
        var action = "TipoCompra";
        ajax_call(data, clazz, action, dibujarComboTipoCompra);
    } else {
        document.getElementById('divTipoCompra').innerHTML = '';
        muestraTipoCompra = 'NO';
    }
}

function dibujarComboTipoCompra(result) {
    //Menor cuantia, Cotizacion, Licitacion
    if ($('txtCodigoTipoCompra').value === "4246" || $('txtCodigoTipoCompra').value === "4245" || $('txtCodigoTipoCompra').value === "387") {
        muestraTipoCompra = 'SI';
    } else {
        muestraTipoCompra = 'NO';
    }

    if (muestraTipoCompra === 'SI') {
        html = '<select id="cmbTipoCompra" onblur="this.style.background="#FFFFFF"; " onfocus="this.style.background="#FFFF99"; " name="cmbTipoCompra" onchange="dibujarComboEstados($(\'txtCodigoTipoCompra\').value)" >';
        html += '<option value="" selected="selected">TODOS</option>';

        result.each(function (val) {
            html += '<option value="' + val.id + '">' + val.tipo + '</option>';
        });
        html += '</select>';
    } else {
        html = '';
    }
    document.getElementById('divTipoCompra').innerHTML = html;
}

//Limpia los campos ingresados
function botonLimpiar() {
    //ET Mantis 2461
    location.reload(true);
}
function dibujarPaginadores() {
    html = '';
    numeroInv = parseInt($F('count'));
    paActual = parseInt($F('paginaActual'));
    siguiente = parseInt(paActual + registroxPagina);
    anterior = parseInt(paActual - registroxPagina);
    if (numeroInv > registroxPagina) {
        html += '<table border="0" cellpadding="0" cellspacing="5">';
        html += '<tr><td colspan="4" align="left">' + numeroPagina() + '</td></tr>';
        html += '<tr>';
        html += '<td align= "left" width="30">' + dibujarDireccionIzD(numeroInv, paActual, siguiente, anterior) + '</td>';
        html += '<td align= "center" width="30">' + dibujarDireccionIz(numeroInv, paActual, siguiente, anterior) + '</td>';
        html += '<td align= "center" width="30">' + dibujarDireccionDer(numeroInv, paActual, siguiente, anterior) + '</td>';
        html += '<td align= "right" width="30">' + dibujarDireccionDerD(numeroInv, paActual, siguiente, anterior) + '</td>';
        html += '</tr>';
        html += '</table>';
    } else {
        html = '<table><tr><td>' + numeroPagina() + '</td></tr></table>';
    }

    return html;
}
function numeroPagina() {
    numeroInv = parseInt($F('count'));
    paActual = parseInt($F('paginaActual'));
    variacion = numeroInv % registroxPagina;
    inicio = paActual + 1;
    totActual = paActual + registroxPagina;
    if (variacion === 0) {
        ultimaPagina = numeroInv - registroxPagina;
    } else {
        ultimaPagina = numeroInv - (numeroInv % registroxPagina);
    }
    if (numeroInv <= registroxPagina) {
        pagina = 'Procesos del ' + inicio + ' al ' + numeroInv + ' de ' + numeroInv;
    } else {
        variacionPagina = numeroInv % paActual;
        if (paActual < ultimaPagina) {
            pagina = 'Procesos del ' + inicio + ' al ' + totActual + ' de ' + numeroInv;
        } else {
            pagina = 'Procesos del ' + inicio + ' al ' + numeroInv + ' de ' + numeroInv;
        }
    }
    return pagina;
}
function dibujarDireccionDerD(numeroInv, paActual, siguiente, anterior) {
    variacion = numeroInv % registroxPagina;
    valorFinal = paActual + variacion;

    if (variacion === 0) {
        ultimaPagina = numeroInv - registroxPagina;
    } else {
        ultimaPagina = numeroInv - (numeroInv % registroxPagina);
    }
    if (paActual === 0 || paActual < ultimaPagina) {

        html = '<a href="javascript:void(0);" onclick="presentarProcesos(' + ultimaPagina + ')">Fin</a>';

    } else {
        html = '&nbsp;';
    }
    return html;
}
function dibujarDireccionDer(numeroInv, paActual, siguiente, anterior) {
    variacion = numeroInv % registroxPagina;
    html = '';

    if (variacion === 0) {
        ultimaPagina = numeroInv - registroxPagina;

    } else {
        ultimaPagina = numeroInv - (numeroInv % registroxPagina);
    }

    variacion = numeroInv - paActual;
    if (paActual === 0 || paActual < ultimaPagina) {
        html += '<a href="javascript:void(0);" onclick="presentarProcesos(' + siguiente + ')">Siguiente</a>';
    } else {
        html = '&nbsp;';
    }
    return html;
}
function dibujarDireccionIz(numeroInv, paActual, siguiente, anterior) {
    if (anterior <= 0) {
        anterior = 0;
    }
    if (paActual !== 0) {
        html = '<a href="javascript:void(0);" onclick="presentarProcesos(' + anterior + ')">Anterior</a>';
    } else {
        html = '&nbsp;';

    }
    return html;
}
function dibujarDireccionIzD(numeroInv, paActual, siguiente, anterior) {
    if (paActual !== 0) {
        html = '<a href="javascript:void(0);" onclick="presentarProcesos(0)">Inicio</a>';
    } else {
        html = '&nbsp;';
    }
    return html;
}

//Inicio Mantis 2296 aalbuja

var ClaseDeFecha = function fecha(cadena) {

    //Separador para la introducción de las fechas  
    var separador = "-";
    //Separa por dia, mes y año  
    if (cadena.indexOf(separador) !== -1) {
        var posi1 = 0;
        var posi2 = cadena.indexOf(separador, posi1 + 3);
        var posi3 = cadena.indexOf(separador, posi2 + 1);
        this.anio = cadena.substring(posi1, posi2);
        this.mes = cadena.substring(posi2 + 1, posi3);
        this.dia = cadena.substring(posi3 + 1, cadena.length);
    } else {
        this.dia = 0;
        this.mes = 0;
        this.anio = 0;
    }
};

function DiferenciaFechas() {

    //Obtiene los datos del formulario  
    var CadenaFecha1 = $F('f_inicio');
    var CadenaFecha2 = $F('f_fin');
    //Obtiene dia, mes y año  
    var fecha1 = new ClaseDeFecha(CadenaFecha1);
    var fecha2 = new ClaseDeFecha(CadenaFecha2);
    //Obtiene objetos Date  
    var miFecha1 = new Date(fecha1.anio, fecha1.mes, fecha1.dia);
    var miFecha2 = new Date(fecha2.anio, fecha2.mes, fecha2.dia);
    //Resta fechas y redondea  
    var diferencia = miFecha2.getTime() - miFecha1.getTime();
    var dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));

    if (dias > 200) {
        alert('El intervalo de Fechas no debe exceder el período de Publicación del Proceso.');
        return false;
    } else {
        return true;
    }
}

function validarFechas() {
    fInicial = $F('f_inicio');
    fFinal = $F('f_fin');
    fA = new Date();
    fActual1 = fA.getFullYear() + "-" + (fA.getMonth() + 1) + "-" + fA.getDate();
    fActual2 = addDate(fActual1, 15, 'D');
    //Fecha inicial no esté vacía
    if (fInicial === '') {
        alert('La fecha desde no debe ser vacia!!');
        return false;
    }
    //Fecha final no esté vacía
    if (fFinal === '') {
        alert('La fecha hasta no debe ser vacia!!');
        return false;
    }
    //15 días después de la fecha de publicación
    if (fA === formatoFecha(fActual2 + ' 00:00:00')) {
        alert("El rango de fechas ingresadas no está dentro del periodo válido de consulta");
        return false;
    }
    //Fecha hasta mayor a la desde y que no sea mayor a 6 meses la búsqueda
    if (fInicial !== '' && fFinal !== '') {
        fInicial = formatoFecha(fInicial + ' 00:00:00');
        fFinal = formatoFecha(fFinal + ' 00:00:00');

        if (fInicial > fFinal) {
            alert('La fecha hasta debe ser mayor a la fecha desde!!');
            return false;
        } else {
            if (DiferenciaFechas()) {
                return true;
            } else {
                return false;
            }
        }
    } else {
        return true;
    }
}



function isset(variable_name) {
    try {
        if (typeof (eval(variable_name)) !== 'undefined') {
            if (eval(variable_name) !== null) {
                return true;
            }
        }
    } catch (e) {
    }
    return false;
}
String.prototype.trim = function () {
    return this.replace(/^\s*|\s*$/g, "");
};
function botonBuscarEntidad() {
    newwindow = window.open('buscarEntidad.cpe?op=1', 'name', 'height=500,width=530,scrollbars=1, toolbar=0, location=0, statusbar=0, menubar=0, resizable=0, left = 250, top = 100'); /// alias
    if (window.focus) {
        newwindow.focus();
    }
    return false;
}
//FUNCTION QUE PERMITE FILTRO POR TIPO DE CONTRATACIÓN
function consultaEstados(idTipo) {
    if (idTipo !== '') {
        var data = "idTipos=" + idTipo;
        var clazz = "ManejadorCatalogo";
        var action = "arregloCatalogoEstados";
        ajax_call(data, clazz, action, comboEstados);
    }
}

function comboEstados(resp) {
    var html = "";
    if (resp !== "") {
        html += '<select name="txtCodigoTipoCompra" id="txtCodigoTipoCompra" onchange=\'dibujarComboEstados(this.value);\'>';
        html += '<option value="">TODOS</option>';
        resp.each(function (listaEstados) {
            html += '<option value="' + listaEstados.i.a + '">' + listaEstados.i.b + '</option>';
        });
        html += '</select>';
        $('divShowEstados').innerHTML = html;
    }
}

function inArray(needle, haystack) {
    var length = haystack.length;
    for (var i = 0; i < length; i++) {
        if (haystack[i] === needle) {
            return true;
        }
    }
    return false;
}

function consultaParametro() {
    var data = "cod=FECHA_OCULTA_VALORES_SIE";
    var clazz = "Parametro";
    var action = "buscarValorParametroSIE";
    ajax_call(data, clazz, action, fechaOcultar);
}
function fechaOcultar(result, resp) {
    fechaOcultaSIE = result['valor'];
}
//3053
function consultaEstadosPE(idTipo) {
    if (idTipo !== '') {
        var data = "idTipos=" + idTipo;
        var clazz = "ManejadorCatalogo";
        var action = "arregloCatalogoEstados";
        ajax_call(data, clazz, action, comboEstadosPE);
    }
}

function comboEstadosPE(resp) {
    var html = "";
    if (resp !== "") {
        html += '<select name="txtCodigoTipoArriendo" id="txtCodigoTipoArriendo">';
        html += '<option value="7116">TODOS</option>';
        resp.each(function (listaEstados) {
            html += '<option value="' + listaEstados.i.a + '">' + listaEstados.i.b + '</option>';
        });
        html += '</select>';
        $('divShowArrenamientos').innerHTML = html;
    }
}
